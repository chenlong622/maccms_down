<?php
// 注意：修改此文件后，需同步更新 application/extra/version.php 中的 update_hash 值
// update_hash = md5_file('application/admin/controller/Update.php')
namespace app\admin\controller;
use think\Db;
use app\common\util\PclZip;

class Update extends Base
{
    var $_url;
    var $_save_path;

    public function __construct()
    {
        parent::__construct();
        //header('X-Accel-Buffering: no');

        $this->_url = base64_decode("aHR0cHM6Ly91cGRhdGUubWFjY21zLmxhLw==")."v10/";
        $this->_save_path = './application/data/update/';
    }

    public function index()
    {
        return $this->fetch('admin@test/index');
    }

    public function step1($file='')
    {
        if(empty($file)){
            return $this->error(lang('param_err'));
        }
        // 白名单：$file 经基址拼接为下载 URL，禁止路径/查询段注入。
        if(!preg_match('/^[a-zA-Z0-9._-]+$/',$file)){
            return $this->error(lang('param_err'));
        }
        $version = config('version.code');
        $url = $this->_url .$file . '.zip?t='.time();

        echo $this->fetch('admin@public/head');
        echo "<div class='update'><h1>".lang('admin/update/step1_a')."</h1><textarea rows=\"25\" class='layui-textarea' readonly>".lang('admin/update/step1_b')."\n";
        ob_flush();flush();
        sleep(1);

        $save_file = $version.'.zip';
        
        $html = mac_curl_get($url, [], '', true);
        if($html === false){
            // TLS 校验失败或拉取失败：拒绝继续，防止 MITM 替换升级包（漏洞 7）。
            echo lang('admin/update/download_err')."\n";
            exit;
        }
        @fwrite(@fopen($this->_save_path.$save_file,'wb'),$html);
        if(!is_file($this->_save_path.$save_file)){
            echo lang('admin/update/download_err')."\n";
            exit;
        }

        if(filesize($this->_save_path.$save_file) <1){
            @unlink($this->_save_path.$save_file);
            echo lang('admin/update/download_err')."\n";
            exit;
        }

        // SHA1校验：.sha1文件进行比对防篡改。经同一强制校验通道获取。
        $sha1_url = $this->_url . $file . '.zip.sha1?t=' . time();
        $remote_sha1_raw = mac_curl_get($sha1_url, [], '', true);
        if($remote_sha1_raw === false){
            @unlink($this->_save_path . $save_file);
            echo lang('admin/update/sha1_err') . "\n";
            exit;
        }
        $remote_sha1 = trim($remote_sha1_raw);
        $local_sha1 = sha1_file($this->_save_path . $save_file);
        if (empty($remote_sha1) || strpos($remote_sha1, $local_sha1) !== 0) {
            @unlink($this->_save_path . $save_file);
            echo lang('admin/update/sha1_err') . "\n";
            exit;
        }
        echo lang('admin/update/sha1_ok') . "\n";

        echo lang('admin/update/download_ok')."\n";
        echo lang('admin/update/upgrade_package_processed')."\n";
        ob_flush();flush();
        sleep(1);

        $archive = new PclZip();
        $archive->PclZip($this->_save_path.$save_file);
        if(!$archive->extract(PCLZIP_OPT_PATH, '', PCLZIP_OPT_REPLACE_NEWER)) {
            echo $archive->error_string."\n";
            echo lang('admin/update/upgrade_err').'' ."\n";;
            exit;
        }
        else{

        }
        @unlink($this->_save_path.$save_file);
        echo '</textarea></div>';
        mac_jump( url('update/step2',['jump'=>1]) ,3);
    }

    public function step2()
    {
        $version = config('version.code');

        $save_file = 'database.php';

        echo $this->fetch('admin@public/head');
        echo "<div class='update'><h1>".lang('admin/update/step2_a')."</h1><textarea rows=\"25\" class='layui-textarea' readonly>\n";
        ob_flush();flush();
        sleep(1);

        $res=true;
        // 导入SQL
        $sql_file = $this->_save_path .$save_file;

        if (is_file($sql_file)) {
            echo lang('admin/update/upgrade_sql')."\n";
            ob_flush();flush();
            $pre = config('database.prefix');
            $schema = Db::query('select * from information_schema.columns where table_schema = ?',[ config('database.database') ]);
            $col_list = [];
            $sql='';
            foreach($schema as $k=>$v){
                $col_list[$v['TABLE_NAME']][$v['COLUMN_NAME']] = $v;
            }
            @include $sql_file;
            //dump($sql);die;

            /*
            //$html =  @file_get_contents($sql_file);
            //$sql = mac_get_body($html,'--'.$version.'-start--','--'.$version.'-end--');
            $sql = @file_get_contents($sql_file);
            */
            if(!empty($sql)) {
                $sql_list = mac_parse_sql($sql, 0, ['mac_' => $pre]);

                if ($sql_list) {
                    $sql_list = array_filter($sql_list);
                    foreach ($sql_list as $v) {
                        echo $v;
                        try {
                            Db::execute($v);
                            echo "    ---".lang('success')."\n\n";
                        } catch (\Exception $e) {
                            echo "    ---".lang('fail')."\n\n";
                        }
                        ob_flush();flush();
                    }
                }
            }
            else{

            }
            @unlink($sql_file);
        }
        else{
            echo lang('admin/update/no_sql')."\n";
        }
        echo '</textarea></div>';
        mac_jump(url('update/step3', ['jump' => 1]), 3);
    }

    public function step3()
    {
        echo $this->fetch('admin@public/head');
        echo "<div class='update'><h1>".lang('admin/update/step3_a')."</h1><div rows=\"25\" class='layui-textarea' readonly>\n";
        ob_flush();flush();
        sleep(1);

        $this->_cache_clear();

        echo lang('admin/update/update_cache')."<br>";
        echo lang('admin/update/upgrade_complete')."<br>";

        if(is_file($this->_save_path . 'database.php')){
            echo "<strong style='color: red;'>" . lang('admin/update/not_delete') . ":application/data/update/database.php</strong>";
        }
        ob_flush();flush();
        echo '</div></div>';
    }
}
